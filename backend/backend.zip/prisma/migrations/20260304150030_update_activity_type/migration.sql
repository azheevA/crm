-- AlterEnum
ALTER TYPE "ActivityType" ADD VALUE 'TASK_UPDATED';
